import React from 'react';
import { Heart, Home as HomeIcon, Users } from 'lucide-react';

export function Home() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div 
        className="relative h-[600px] bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Welcome to Luxury Assisted Living
            </h1>
            <p className="text-xl md:text-2xl mb-8">
              Providing exceptional care in a comfortable and luxurious environment
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Us</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <div className="flex justify-center mb-4">
                <HomeIcon size={48} className="text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Luxury Accommodations</h3>
              <p className="text-gray-600">
                Five private bedrooms with walk-in closets and modern amenities
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <div className="flex justify-center mb-4">
                <Users size={48} className="text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Professional Care</h3>
              <p className="text-gray-600">
                Round-the-clock monitoring and supervision by trained staff
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <div className="flex justify-center mb-4">
                <Heart size={48} className="text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Personalized Care</h3>
              <p className="text-gray-600">
                Custom care plans tailored to each resident's needs
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}