import React from 'react';
import { Activity, Shield, UserCheck, Clock, Bell, Pill, Bath, Scissors, Coffee, Car, Shirt, Home, Wifi, PartyPopper } from 'lucide-react';

export function Services() {
  const services = [
    {
      icon: <Clock className="w-8 h-8 text-indigo-600" />,
      title: "24/7 Monitoring",
      description: "Twenty-four hours monitoring and supervision to ensure the health, wellbeing, and safety of each resident."
    },
    {
      icon: <Shield className="w-8 h-8 text-indigo-600" />,
      title: "Security System",
      description: "Automated Security System for resident safety"
    },
    {
      icon: <UserCheck className="w-8 h-8 text-indigo-600" />,
      title: "Custom Care Plan",
      description: "Custom Personal Care Plan tailored to each resident"
    },
    {
      icon: <Pill className="w-8 h-8 text-indigo-600" />,
      title: "Medication Assistance",
      description: "Medication Assistance/Reminders, which are in line with physician and/or pharmacist requirements"
    },
    {
      icon: <Bath className="w-8 h-8 text-indigo-600" />,
      title: "Personal Care",
      description: "Assistance with bathing, dressing, grooming; based on recommendation recipient's plan of Adult Daily Living"
    },
    {
      icon: <Scissors className="w-8 h-8 text-indigo-600" />,
      title: "Hand & Nail Care",
      description: "Hand and nail foot care services"
    },
    {
      icon: <Coffee className="w-8 h-8 text-indigo-600" />,
      title: "Meals & Snacks",
      description: "Three nutritious meals daily and snacks"
    },
    {
      icon: <Car className="w-8 h-8 text-indigo-600" />,
      title: "Transportation",
      description: "Most transportation services per residential service contract"
    },
    {
      icon: <Shirt className="w-8 h-8 text-indigo-600" />,
      title: "Laundry Services",
      description: "Laundry of linens and personal items"
    },
    {
      icon: <Home className="w-8 h-8 text-indigo-600" />,
      title: "Housekeeping",
      description: "Housekeeping services and/or assistance as needed"
    },
    {
      icon: <PartyPopper className="w-8 h-8 text-indigo-600" />,
      title: "Special Events",
      description: "Special parties for recipient's personal visitors"
    },
    {
      icon: <Wifi className="w-8 h-8 text-indigo-600" />,
      title: "Internet Access",
      description: "Internet is provided for use of recipient's personal devices"
    },
    {
      icon: <Activity className="w-8 h-8 text-indigo-600" />,
      title: "Activities",
      description: "Daily recreational activities for groups or individuals"
    }
  ];

  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Our Services</h1>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Luxury Assisted Living, LLC, believes being active and involved in agency
            activities helps residents to strengthen social skills and to help build a home
            community within the Agency with residents and staff. We encourage our residents
            to participate in activities and recreations within their capabilities, wants, and
            needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                {service.icon}
                <h3 className="text-xl font-semibold text-gray-900 ml-3">{service.title}</h3>
              </div>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 italic">
            We respect the right of a resident to choose not to participate. When possible, 
            staff will devote time to the recipient's activities, and will make the 
            recipient's stimulation, involvement, and enjoyment a priority.
          </p>
        </div>
      </div>
    </div>
  );
}