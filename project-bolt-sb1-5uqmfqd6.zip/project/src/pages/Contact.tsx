import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Contact() {
  const contactInfo = [
    {
      icon: <MapPin className="w-6 h-6 text-indigo-600" />,
      title: "Address",
      content: "1705 N Church Rd, Wasilla, Alaska 99654",
      link: "https://maps.google.com/?q=1705+N+Church+Rd,+Wasilla,+Alaska+99654"
    },
    {
      icon: <Phone className="w-6 h-6 text-indigo-600" />,
      title: "Phone",
      content: "(907) 317-5881",
      link: "tel:+19073175881"
    },
    {
      icon: <Clock className="w-6 h-6 text-indigo-600" />,
      title: "Hours",
      content: "24/7 Availability",
      link: null
    }
  ];

  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Contact Us</h1>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            We're here to answer any questions you may have about our assisted living services.
            Feel free to reach out to us using any of the methods below.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {contactInfo.map((info, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex flex-col items-center text-center">
                <div className="mb-4">
                  {info.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{info.title}</h3>
                {info.link ? (
                  <a
                    href={info.link}
                    className="text-indigo-600 hover:text-indigo-800 transition-colors duration-300"
                    target={info.title === "Address" ? "_blank" : undefined}
                    rel={info.title === "Address" ? "noopener noreferrer" : undefined}
                  >
                    {info.content}
                  </a>
                ) : (
                  <p className="text-gray-600">{info.content}</p>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 rounded-lg p-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6 text-center">Visit Our Facility</h2>
          <div className="aspect-w-16 aspect-h-9">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1957.7174766370422!2d-149.4534084!3d61.5812247!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x56c8b6b76c8080cf%3A0x8dd6e04c4f039690!2s1705%20N%20Church%20Rd%2C%20Wasilla%2C%20AK%2099654!5e0!3m2!1sen!2sus!4v1710367248927!5m2!1sen!2sus"
              className="w-full h-[400px] rounded-lg"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
}