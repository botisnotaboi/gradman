import React from 'react';

export function About() {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Vision Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Vision</h2>
          <p className="text-lg text-gray-700">
            To maintain a safe, healthy, and nurturing environment while growing and living with
            independence in Luxury Assisted Living, LLC.
          </p>
        </section>

        {/* Mission Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Mission</h2>
          <p className="text-lg text-gray-700">
            To ensure our recipient's needs are met and they feel comfortable and safe in Luxury Assisted
            Living, LLC, through trust and respect.
          </p>
        </section>

        {/* Philosophy Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Philosophy</h2>
          <p className="text-lg text-gray-700 mb-6">
            Luxury Assisted Living, LLC, will promote wellness and quality of life to the recipients:
          </p>
          <ul className="list-disc list-inside space-y-3 text-gray-700">
            <li>By recognizing, accepting, and respecting individual needs and decisions.</li>
            <li>By respecting residents' rights to privacy and confidentiality.</li>
            <li>By affirming the importance of "Residents' Rights" daily.</li>
            <li>By collaborating with health care delivery systems to effect positive resident outcomes.</li>
            <li>By maintaining and/or restoring our residents' health to the highest practicable level of functioning.</li>
            <li>By striving to relieve pain, discomfort, anxiety, and fear wherever possible.</li>
            <li>By encouraging residents to seek enjoyment of life through hobbies and activities of their own choosing.</li>
            <li>By providing activities to promote health, wellness, and a sense of community.</li>
            <li>By providing opportunities for community involvement, service, and socialization.</li>
            <li>By acting as an advocate for our residents where and as appropriate.</li>
            <li>By providing and coordinating personal and professional resources as appropriate.</li>
            <li>By providing information that assists residents and their families in making well-informed personal healthcare decisions.</li>
            <li>By providing a support framework for residents' families.</li>
            <li>By providing knowledgeable staff who are trained, on an ongoing basis, to deliver care that is consistent with the best practice standards.</li>
            <li>By providing a positive and healthy working environment that promotes the health and wellness of our valued staff.</li>
          </ul>
        </section>

        {/* Certification Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Licensing & Certification</h2>
          <div className="prose prose-lg text-gray-700">
            <p className="mb-4">
              Licensed and Certified with the State of Alaska Department of Health and Division
              of Senior and Disabilities Services; Residential Supported Living; ALI, APDD
              programs and Residential Habilitation; APDD, IDD programs.
            </p>
            <p className="mb-4">
              Provide services for five (5) adults, 18 years of age or older:
            </p>
            <ul className="list-disc list-inside mb-4">
              <li>Intellectual and Development Disabilities, IDD</li>
              <li>Physically Disabled Seniors, ALI</li>
              <li>Adults with Physical and Developmental Disabilities, elderly, or suffer from dementia, APDD</li>
            </ul>
            <p className="mb-4">
              We do not provide services for chronically mentally ill (SS).
            </p>
            <p>
              The house is designed to manage the needs of those residents who can navigate
              stairs, and one room downstairs is equipped for a resident who has a physical
              disability. An alarm system is maintained for the safety of all residents, and those
              with dementia, or a tendency to wander. The agency is staffed to ensure residents
              receive the required monitoring and supervision to meet the recipient's needs.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}