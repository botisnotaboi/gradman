import React from 'react';
import { Bed, Moon, Bath, Home } from 'lucide-react';

export function Accommodations() {
  const features = [
    {
      icon: <Bed className="w-8 h-8 text-indigo-600" />,
      title: "Furnished Bedrooms",
      description: "Each bedroom comes with a bed (including sheets and bedspread), one or two nightstands, and a dresser"
    },
    {
      icon: <Moon className="w-8 h-8 text-indigo-600" />,
      title: "Private Space",
      description: "All 5 bedrooms are private and feature walk-in closets for ample storage"
    },
    {
      icon: <Bath className="w-8 h-8 text-indigo-600" />,
      title: "Full Bathrooms",
      description: "Downstairs bathroom shared with kitchen and common area, plus two full bathrooms upstairs"
    },
    {
      icon: <Home className="w-8 h-8 text-indigo-600" />,
      title: "Laundry Facilities",
      description: "Convenient laundry room located upstairs"
    }
  ];

  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Living Quarters</h1>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Our facility features comfortable, private accommodations designed to make our residents
            feel at home, with all the amenities needed for a comfortable stay.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                {feature.icon}
                <h3 className="text-xl font-semibold text-gray-900 ml-3">{feature.title}</h3>
              </div>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 rounded-lg p-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Additional Amenities</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <Bath className="w-6 h-6 text-indigo-600 mt-1" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Bath Linens</h3>
                <p className="text-gray-600">
                  Towels are provided for bathing, and fresh hand towels are placed daily in the bathrooms
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <Home className="w-6 h-6 text-indigo-600 mt-1" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Accessibility</h3>
                <p className="text-gray-600">
                  One downstairs bedroom is specially equipped for residents with physical disabilities
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}