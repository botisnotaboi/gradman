import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Services } from './pages/Services';
import { Accommodations } from './pages/Accommodations';
import { Contact } from './pages/Contact';
import { Menu, X } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-white">
        <nav className="bg-indigo-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="text-white font-bold text-xl">
                  Luxury Assisted Living
                </Link>
              </div>
              
              {/* Desktop Navigation */}
              <div className="hidden md:block">
                <div className="ml-10 flex items-baseline space-x-4">
                  <Link to="/" className="text-white hover:bg-indigo-500 px-3 py-2 rounded-md">Home</Link>
                  <Link to="/about" className="text-white hover:bg-indigo-500 px-3 py-2 rounded-md">About</Link>
                  <Link to="/services" className="text-white hover:bg-indigo-500 px-3 py-2 rounded-md">Services</Link>
                  <Link to="/accommodations" className="text-white hover:bg-indigo-500 px-3 py-2 rounded-md">Accommodations</Link>
                  <Link to="/contact" className="text-white hover:bg-indigo-500 px-3 py-2 rounded-md">Contact</Link>
                </div>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-white hover:bg-indigo-500 p-2 rounded-md"
                >
                  {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <Link to="/" className="text-white hover:bg-indigo-500 block px-3 py-2 rounded-md">Home</Link>
                <Link to="/about" className="text-white hover:bg-indigo-500 block px-3 py-2 rounded-md">About</Link>
                <Link to="/services" className="text-white hover:bg-indigo-500 block px-3 py-2 rounded-md">Services</Link>
                <Link to="/accommodations" className="text-white hover:bg-indigo-500 block px-3 py-2 rounded-md">Accommodations</Link>
                <Link to="/contact" className="text-white hover:bg-indigo-500 block px-3 py-2 rounded-md">Contact</Link>
              </div>
            </div>
          )}
        </nav>

        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/accommodations" element={<Accommodations />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>

        <footer className="bg-gray-800 text-white py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p>© 2024 Luxury Assisted Living LLC. All rights reserved.</p>
              <p className="mt-2">1705 N Church Rd, Wasilla, Alaska 99654</p>
              <p className="mt-2">Phone: (907) 317-5881</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;